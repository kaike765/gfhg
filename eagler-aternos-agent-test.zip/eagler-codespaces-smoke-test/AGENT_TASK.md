# Handoff para agente: teste de viabilidade Eaglercraft ↔ Aternos

## Objetivo
Investigar se existe caminho suportado para o cliente Eaglercraft 1.12 WASM-GC fornecido conectar ao servidor Aternos abaixo, **mantendo intacta a autenticação oficial do servidor**.

- Host: `gustavoklucinec.aternos.me`
- Porta informada: `58275`
- Proxy pretendido: GitHub Codespaces
- Cliente: HTML Eaglercraft 1.12 WASM-GC Offline

## Restrições obrigatórias
- Não desativar `online-mode` nem ativar modo cracked/offline.
- Não solicitar, armazenar, retransmitir ou inventar credenciais, cookies ou tokens Microsoft/Minecraft.
- Não contornar autenticação nem falsificar perfil/UUID.
- Não presumir que uma whitelist substitui autenticação de conta.
- Não publicar segredo, IP privado ou arquivo de credenciais.

## Evidências de rede já obtidas pelo usuário
- O TCP do Codespace alcançou `gustavoklucinec.aternos.me:58275`; o teste abriu e fechou a conexão sem enviar pacote Minecraft.
- O teste WebSocket de eco no Codespace abriu, recebeu `ready` e devolveu o texto `ping de teste`.
- Esses testes validam conectividade básica, não o handshake Minecraft, o protocolo Eaglercraft ou a autenticação.

## Tarefa do agente
1. Verificar documentação oficial atual de EaglerXServer, ViaVersion/ViaBackwards, Velocity/Bungee e Aternos.
2. Determinar se o cliente Eaglercraft indicado pode autenticar-se em um backend Aternos `online-mode=true` por meio de um proxy, sem credenciais Microsoft no cliente e sem alterar o backend.
3. Se houver um caminho suportado, descrever os pré-requisitos e fornecer apenas configuração que preserve autenticação oficial e encaminhamento seguro.
4. Se não houver, declarar o bloqueio técnico com clareza. Não criar uma configuração que aparenta funcionar, mas falha na autenticação.

## Diagnóstico TCP opcional
`node tcp-check.js` testa apenas se uma conexão TCP consegue abrir para o host/porta acima. Não envia credenciais ou pacotes Minecraft.
